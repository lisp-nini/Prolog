:- dynamic my_fail/0.

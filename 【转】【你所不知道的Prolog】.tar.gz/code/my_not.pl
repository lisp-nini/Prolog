my_not(X) :-
    once(X) -> fail ; true.

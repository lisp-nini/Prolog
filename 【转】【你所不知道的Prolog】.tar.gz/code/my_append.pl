my_append([],L,L).
my_append([H|T],L2,[H|L3])  :-  my_append(T,L2,L3). 

my_once(X) :-
    call(X),
    !.


if_then_else(A,B,C) :-
    once(A), !,
    call(B).
if_then_else(A,B,C) :-
    call(C).


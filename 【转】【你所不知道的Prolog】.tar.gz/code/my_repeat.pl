my_repeat.
my_repeat :- my_repeat.

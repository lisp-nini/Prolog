:- dynamic p/1.

p(1) :- !,
    write(X), nl.
p(X) :-
    write('not 1: '), write(X), nl.

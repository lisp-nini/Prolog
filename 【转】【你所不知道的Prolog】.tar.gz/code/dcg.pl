whitespace --> " ".

if_then(Cond, Result) -->
    "if", whitespace, expr(Cond), whitespace, "then", whitespace, expr(Result),
    { write('got if then'), nl }.
    
expr(true) -->
    "true",
    { write('got true'), nl }.
expr(false) -->
    "false",
    { write('got false'), nl }.


%% if_then(Cond, Result, "if true then false   rest", Rest).    



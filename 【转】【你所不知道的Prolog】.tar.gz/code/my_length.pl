my_length(List, Len) :-
    my_length(List, 0, Len).

my_length([], Len, Len) :- !.
my_length([_|T], N, Len) :-
    N1 is N + 1,
    my_length(T, N1, Len).
